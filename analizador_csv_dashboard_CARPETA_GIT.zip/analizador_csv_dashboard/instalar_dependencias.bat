@echo off
title Instalador de dependencias
echo Instalando dependencias...
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo Probando con py...
  py -m pip install -r requirements.txt
)
pause
