# Instalación y uso

## 1. Instalar dependencias

```powershell
python -m pip install -r requirements.txt
```

Si no funciona:

```powershell
py -m pip install -r requirements.txt
```

## 2. Ejecutar el sistema

```powershell
python -m streamlit run app.py
```

Si no funciona:

```powershell
py -m streamlit run app.py
```

## 3. Abrir en navegador

Normalmente se abrirá solo. Si no, entrar a:

```text
http://localhost:8501
```
