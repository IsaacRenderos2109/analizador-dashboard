@echo off
title Analizador CSV Dashboard
echo Iniciando sistema...
python -m streamlit run app.py
if errorlevel 1 (
  echo Probando con py...
  py -m streamlit run app.py
)
pause
