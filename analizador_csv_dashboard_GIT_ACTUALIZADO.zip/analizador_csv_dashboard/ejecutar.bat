@echo off
setlocal
title Ejecutar - Analizador CSV Dashboard
cd /d "%~dp0"

echo ==========================================================
echo   ANALIZADOR CSV DASHBOARD
echo ==========================================================
echo.

if exist ".venv\Scripts\python.exe" (
    echo Usando entorno virtual local .venv...
    ".venv\Scripts\python.exe" -m streamlit run app.py
    goto END
)

echo No se encontro .venv. Se intentara con Python del sistema.
python -m streamlit run app.py
if %errorlevel%==0 goto END

py -3 -m streamlit run app.py
if %errorlevel%==0 goto END

echo.
echo ERROR: No se pudo ejecutar el sistema.
echo Primero ejecute: instalar_dependencias.bat
pause

:END
endlocal
