@echo off
setlocal enabledelayedexpansion
title Instalador - Analizador CSV Dashboard
cd /d "%~dp0"

echo ==========================================================
echo   INSTALADOR DEL ANALIZADOR CSV DASHBOARD
echo ==========================================================
echo.
echo Este instalador verifica Python, intenta instalarlo si no existe,
echo actualiza pip e instala las dependencias del proyecto.
echo.

set "PYTHON_CMD="

echo [1/6] Verificando Python...
python -c "import sys" >nul 2>&1
if %errorlevel%==0 (
    set "PYTHON_CMD=python"
    goto PYTHON_FOUND
)

py -3 -c "import sys" >nul 2>&1
if %errorlevel%==0 (
    set "PYTHON_CMD=py -3"
    goto PYTHON_FOUND
)

echo Python no esta instalado o no esta agregado al PATH.
echo.

echo [2/6] Intentando instalar Python con winget...
where winget >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: winget no esta disponible.
    echo Instale Python manualmente desde:
    echo https://www.python.org/downloads/
    echo Marque la opcion: Add Python to PATH
    pause
    exit /b 1
)

winget install -e --id Python.Python.3.12 --accept-source-agreements --accept-package-agreements

set "PATH=%LocalAppData%\Programs\Python\Python312;%LocalAppData%\Programs\Python\Python312\Scripts;%PATH%"

python -c "import sys" >nul 2>&1
if %errorlevel%==0 (
    set "PYTHON_CMD=python"
    goto PYTHON_FOUND
)

py -3 -c "import sys" >nul 2>&1
if %errorlevel%==0 (
    set "PYTHON_CMD=py -3"
    goto PYTHON_FOUND
)

echo ERROR: Python no pudo verificarse despues de la instalacion.
echo Cierre PowerShell/CMD, abralo de nuevo y ejecute este archivo otra vez.
pause
exit /b 1

:PYTHON_FOUND
echo Python detectado:
%PYTHON_CMD% --version
echo.

echo [3/6] Intentando actualizar Python con winget, si aplica...
where winget >nul 2>&1
if %errorlevel%==0 (
    winget upgrade -e --id Python.Python.3.12 --accept-source-agreements --accept-package-agreements
    winget upgrade -e --id Python.Python.3.13 --accept-source-agreements --accept-package-agreements
) else (
    echo winget no disponible. Se continua sin actualizar Python.
)
echo.

echo [4/6] Creando entorno virtual .venv...
if not exist ".venv" (
    %PYTHON_CMD% -m venv .venv
) else (
    echo El entorno virtual .venv ya existe.
)

if exist ".venv\Scripts\python.exe" (
    set "ENV_PY=.venv\Scripts\python.exe"
) else (
    echo No se pudo crear .venv. Se usara Python del sistema.
    set "ENV_PY=%PYTHON_CMD%"
)

echo.
echo [5/6] Actualizando pip...
%ENV_PY% -m pip install --upgrade pip

echo.
echo [6/6] Instalando dependencias...
%ENV_PY% -m pip install -r requirements.txt

if %errorlevel% neq 0 (
    echo ERROR: No se pudieron instalar las dependencias.
    pause
    exit /b 1
)

echo.
echo ==========================================================
echo   INSTALACION FINALIZADA CORRECTAMENTE
echo ==========================================================
echo.
echo Ahora ejecute: ejecutar.bat
pause
exit /b 0
