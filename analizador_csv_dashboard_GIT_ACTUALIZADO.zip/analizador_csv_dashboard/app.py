
import re
import csv
import io
import unicodedata
from datetime import datetime

import pandas as pd
import streamlit as st
import plotly.express as px


# ==========================================================
# CONFIGURACIÓN
# ==========================================================

st.set_page_config(
    page_title="Analizador CSV y Dashboard",
    page_icon="📊",
    layout="wide"
)

st.title("📊 Analizador de CSV y generador de dashboards")
st.caption(
    "Subí un CSV, revisá filas y columnas, perfilá los datos y generá gráficos automáticos a partir de preguntas definidas."
)


# ==========================================================
# FUNCIONES GENERALES
# ==========================================================

def normalizar_texto(valor):
    valor = str(valor).strip().lower()
    valor = "".join(
        c for c in unicodedata.normalize("NFD", valor)
        if unicodedata.category(c) != "Mn"
    )
    valor = re.sub(r"[^a-z0-9]+", " ", valor)
    valor = re.sub(r"\s+", " ", valor).strip()
    return valor


def detectar_separador(uploaded_file):
    uploaded_file.seek(0)
    muestra = uploaded_file.read(4096)
    uploaded_file.seek(0)

    if isinstance(muestra, bytes):
        muestra = muestra.decode("utf-8-sig", errors="ignore")

    try:
        dialecto = csv.Sniffer().sniff(muestra, delimiters=[",", ";", "\t", "|"])
        return dialecto.delimiter
    except Exception:
        return ","


@st.cache_data(show_spinner=False)
def leer_csv(file_bytes, separador):
    try:
        df = pd.read_csv(
            io.BytesIO(file_bytes),
            sep=separador,
            dtype=str,
            encoding="utf-8-sig",
            keep_default_na=False,
            low_memory=False
        )
        return df, "utf-8-sig"
    except UnicodeDecodeError:
        df = pd.read_csv(
            io.BytesIO(file_bytes),
            sep=separador,
            dtype=str,
            encoding="latin1",
            keep_default_na=False,
            low_memory=False
        )
        return df, "latin1"


def detectar_columnas_eliminar(df):
    columnas_eliminar = []

    for col in df.columns:
        if "ELIMINAR COLUMNA" in str(col).upper():
            columnas_eliminar.append(col)

    primera_fila_es_marcador = False

    if len(df) > 0:
        for col in df.columns:
            valor = str(df[col].iloc[0]).strip().upper()
            if "ELIMINAR COLUMNA" in valor:
                columnas_eliminar.append(col)
                primera_fila_es_marcador = True

    columnas_eliminar = list(dict.fromkeys(columnas_eliminar))
    return columnas_eliminar, primera_fila_es_marcador


def limpiar_columnas_eliminar(df):
    columnas_eliminar, primera_fila_es_marcador = detectar_columnas_eliminar(df)
    df_limpio = df.copy()

    if columnas_eliminar:
        df_limpio = df_limpio.drop(columns=columnas_eliminar, errors="ignore")

    if primera_fila_es_marcador:
        df_limpio = df_limpio.iloc[1:].copy()

    return df_limpio, columnas_eliminar, primera_fila_es_marcador


def obtener_perfil_dataframe(df):
    perfil = pd.DataFrame({
        "columna": df.columns,
        "tipo_actual": [str(df[col].dtype) for col in df.columns],
        "valores_no_vacios": [df[col].replace("", pd.NA).notna().sum() for col in df.columns],
        "valores_vacios": [df[col].replace("", pd.NA).isna().sum() for col in df.columns],
        "valores_unicos": [df[col].nunique(dropna=False) for col in df.columns],
        "ejemplo": [
            df[col].dropna().astype(str).head(1).to_list()[0]
            if len(df[col].dropna()) else ""
            for col in df.columns
        ]
    })
    return perfil


def detectar_columnas_por_tipo(df):
    numericas = []
    fechas = []
    categoricas = []

    for col in df.columns:
        serie = df[col].replace("", pd.NA).dropna().astype(str)

        if len(serie) == 0:
            categoricas.append(col)
            continue

        muestra = serie.head(5000)

        convert_num = pd.to_numeric(muestra, errors="coerce")
        porcentaje_num = convert_num.notna().mean()

        convert_fecha = pd.to_datetime(muestra, errors="coerce")
        porcentaje_fecha = convert_fecha.notna().mean()

        if porcentaje_num >= 0.80:
            numericas.append(col)
        elif porcentaje_fecha >= 0.80:
            fechas.append(col)
        else:
            categoricas.append(col)

    return numericas, categoricas, fechas


def convertir_columna_numerica(df, columna):
    return pd.to_numeric(df[columna].replace("", pd.NA), errors="coerce")


def convertir_columna_fecha(df, columna):
    return pd.to_datetime(df[columna].replace("", pd.NA), errors="coerce")


def es_si(valor):
    texto = normalizar_texto(valor)
    return texto in ["si", "s", "1", "true", "verdadero", "yes"]


def es_confirmado(valor):
    texto = normalizar_texto(valor)
    return "confirmado" in texto


def buscar_columna(df, candidatos):
    """
    Busca una columna aunque venga en mayúsculas, minúsculas o con variaciones.
    """
    mapa = {normalizar_texto(col): col for col in df.columns}

    # exacto
    for cand in candidatos:
        cand_norm = normalizar_texto(cand)
        if cand_norm in mapa:
            return mapa[cand_norm]

    # contiene
    for cand in candidatos:
        cand_norm = normalizar_texto(cand)
        for col_norm, col_real in mapa.items():
            if cand_norm in col_norm or col_norm in cand_norm:
                return col_real

    # tokens
    for cand in candidatos:
        tokens = [t for t in normalizar_texto(cand).split() if len(t) >= 4]
        for col_norm, col_real in mapa.items():
            if tokens and all(t in col_norm for t in tokens):
                return col_real

    return None


def detectar_columnas_salud(df):
    return {
        "fecha": buscar_columna(df, ["fecha_actualizacion", "fecha actualizacion", "fecha"]),
        "defuncion": buscar_columna(df, ["defuncion", "fallecido", "fallecimiento"]),
        "hipertension": buscar_columna(df, ["hipertension", "hta"]),
        "diabetes": buscar_columna(df, ["diabetes"]),
        "entidad": buscar_columna(df, ["entidad_res_desc", "entidad residencia", "entidad"]),
        "dictamen": buscar_columna(df, ["dictamen_desc", "dictamen", "diagnostico"]),
        "estatus": buscar_columna(df, ["estatus_caso_desc", "estatus caso", "estado caso", "estatus"])
    }


def crear_grafico_generico(df, tipo, x=None, y=None, color=None, top_n=20):
    data = df.copy()

    if tipo == "Conteo por categoría":
        conteo = (
            data[x]
            .replace("", "Sin dato")
            .value_counts()
            .head(top_n)
            .reset_index()
        )
        conteo.columns = [x, "total"]
        fig = px.bar(conteo, x=x, y="total", text="total", title=f"Conteo por {x}")
        fig.update_traces(textposition="outside")
        return fig, conteo

    if tipo == "Gráfico circular":
        conteo = (
            data[x]
            .replace("", "Sin dato")
            .value_counts()
            .head(top_n)
            .reset_index()
        )
        conteo.columns = [x, "total"]
        fig = px.pie(conteo, names=x, values="total", title=f"Distribución de {x}", hole=0.35)
        return fig, conteo

    if tipo == "Histograma":
        data["_valor_numerico_"] = convertir_columna_numerica(data, x)
        fig = px.histogram(
            data.dropna(subset=["_valor_numerico_"]),
            x="_valor_numerico_",
            nbins=30,
            title=f"Histograma de {x}"
        )
        fig.update_layout(xaxis_title=x, yaxis_title="Frecuencia")
        return fig, data[[x]].describe()

    if tipo == "Barras cruzadas":
        tabla = (
            data.groupby([x, y])
            .size()
            .reset_index(name="total")
            .sort_values("total", ascending=False)
            .head(top_n)
        )
        fig = px.bar(tabla, x=x, y="total", color=y, text="total", title=f"{x} por {y}")
        return fig, tabla

    if tipo == "Línea por fecha":
        data["_fecha_"] = convertir_columna_fecha(data, x)
        data = data.dropna(subset=["_fecha_"])
        tabla = (
            data.groupby(data["_fecha_"].dt.date)
            .size()
            .reset_index(name="total")
        )
        tabla.columns = ["fecha", "total"]
        fig = px.line(tabla, x="fecha", y="total", markers=True, title=f"Registros por fecha: {x}")
        return fig, tabla

    if tipo == "Dispersión":
        data["_x_num_"] = convertir_columna_numerica(data, x)
        data["_y_num_"] = convertir_columna_numerica(data, y)
        muestra = data.dropna(subset=["_x_num_", "_y_num_"]).head(50000)

        fig = px.scatter(
            muestra,
            x="_x_num_",
            y="_y_num_",
            color=color if color else None,
            title=f"Dispersión: {x} vs {y}"
        )
        fig.update_layout(xaxis_title=x, yaxis_title=y)
        return fig, muestra[[x, y]].head(50)

    return None, None


def generar_dashboard_salud(df, top_n=15):
    cols = detectar_columnas_salud(df)
    resultados = {}

    # Pregunta 1
    if cols["defuncion"] and cols["estatus"]:
        filtro = df[cols["defuncion"]].apply(es_si)
        q1 = (
            df[filtro]
            .groupby(cols["estatus"])
            .size()
            .reset_index(name="total_fallecidos")
            .sort_values("total_fallecidos", ascending=False)
        )
        resultados["q1"] = q1

    # Pregunta 2
    if cols["hipertension"] and cols["dictamen"]:
        filtro = df[cols["hipertension"]].apply(es_si)
        q2 = (
            df[filtro]
            .groupby(cols["dictamen"])
            .size()
            .reset_index(name="total_pacientes_hipertension")
            .sort_values("total_pacientes_hipertension", ascending=False)
        )
        resultados["q2"] = q2

    # Pregunta 3
    if cols["estatus"] and cols["entidad"]:
        filtro = df[cols["estatus"]].apply(es_confirmado)
        q3 = (
            df[filtro]
            .groupby(cols["entidad"])
            .size()
            .reset_index(name="total_confirmados")
            .sort_values("total_confirmados", ascending=False)
        )
        resultados["q3"] = q3

    # Pregunta 4
    if cols["fecha"]:
        fechas = convertir_columna_fecha(df, cols["fecha"])
        resultados["q4"] = fechas.max()

    # Pregunta 5
    if cols["estatus"] and cols["diabetes"]:
        filtro = df[cols["estatus"]].apply(es_confirmado)
        q5 = (
            df[filtro]
            .groupby(cols["diabetes"])
            .size()
            .reset_index(name="total_pacientes")
            .sort_values("total_pacientes", ascending=False)
        )
        resultados["q5"] = q5

    return cols, resultados


def interpretar_pregunta_usuario(pregunta, df):
    """
    Asistente por reglas: detecta preguntas parecidas a las del enunciado y genera gráfico.
    No usa internet ni API externa.
    """
    p = normalizar_texto(pregunta)
    cols = detectar_columnas_salud(df)

    # 1. Fallecidos por estatus
    if any(x in p for x in ["fallecido", "fallecidos", "defuncion", "defunciones"]) and any(x in p for x in ["estatus", "estado caso", "caso"]):
        if cols["defuncion"] and cols["estatus"]:
            filtro = df[cols["defuncion"]].apply(es_si)
            tabla = (
                df[filtro]
                .groupby(cols["estatus"])
                .size()
                .reset_index(name="total_fallecidos")
                .sort_values("total_fallecidos", ascending=False)
            )
            fig = px.bar(
                tabla,
                x=cols["estatus"],
                y="total_fallecidos",
                text="total_fallecidos",
                title="Pacientes fallecidos por estatus del caso"
            )
            fig.update_traces(textposition="outside")
            return "Pregunta detectada: pacientes fallecidos por estatus del caso.", fig, tabla

    # 2. Hipertensión por dictamen
    if "hipertension" in p and "dictamen" in p:
        if cols["hipertension"] and cols["dictamen"]:
            filtro = df[cols["hipertension"]].apply(es_si)
            tabla = (
                df[filtro]
                .groupby(cols["dictamen"])
                .size()
                .reset_index(name="total_pacientes_hipertension")
                .sort_values("total_pacientes_hipertension", ascending=False)
            )
            fig = px.bar(
                tabla,
                x="total_pacientes_hipertension",
                y=cols["dictamen"],
                orientation="h",
                text="total_pacientes_hipertension",
                title="Pacientes con hipertensión por dictamen"
            )
            fig.update_traces(textposition="outside")
            return "Pregunta detectada: pacientes con hipertensión por dictamen.", fig, tabla

    # 3. Confirmados por entidad
    if any(x in p for x in ["confirmado", "confirmados"]) and any(x in p for x in ["entidad", "residencia"]):
        if cols["estatus"] and cols["entidad"]:
            filtro = df[cols["estatus"]].apply(es_confirmado)
            tabla = (
                df[filtro]
                .groupby(cols["entidad"])
                .size()
                .reset_index(name="total_confirmados")
                .sort_values("total_confirmados", ascending=False)
            )
            graf = tabla.head(15).sort_values("total_confirmados")
            fig = px.bar(
                graf,
                x="total_confirmados",
                y=cols["entidad"],
                orientation="h",
                text="total_confirmados",
                title="Pacientes confirmados por entidad de residencia"
            )
            fig.update_traces(textposition="outside")
            return "Pregunta detectada: pacientes confirmados por entidad de residencia.", fig, tabla

    # 4. Fecha más reciente
    if "fecha" in p and any(x in p for x in ["reciente", "ultima", "actualizacion", "maxima"]):
        if cols["fecha"]:
            fecha = convertir_columna_fecha(df, cols["fecha"]).max()
            tabla = pd.DataFrame({
                "metrica": ["fecha_actualizacion_mas_reciente"],
                "resultado": [fecha.strftime("%Y-%m-%d") if pd.notna(fecha) else "No disponible"]
            })
            return "Pregunta detectada: fecha de actualización más reciente.", None, tabla

    # 5. Confirmados con diabetes y sin diabetes
    if "diabetes" in p and any(x in p for x in ["confirmado", "confirmados", "estatus"]):
        if cols["estatus"] and cols["diabetes"]:
            filtro = df[cols["estatus"]].apply(es_confirmado)
            tabla = (
                df[filtro]
                .groupby(cols["diabetes"])
                .size()
                .reset_index(name="total_pacientes")
                .sort_values("total_pacientes", ascending=False)
            )
            fig = px.pie(
                tabla,
                names=cols["diabetes"],
                values="total_pacientes",
                hole=0.35,
                title="Pacientes confirmados con diabetes y sin diabetes"
            )
            return "Pregunta detectada: pacientes confirmados con diabetes y sin diabetes.", fig, tabla

    # Respuesta genérica por columna
    mapa = {normalizar_texto(col): col for col in df.columns}
    columnas_mencionadas = []

    for col_norm, col_real in mapa.items():
        partes = [x for x in col_norm.split() if len(x) >= 4]
        if col_norm in p or any(x in p for x in partes):
            columnas_mencionadas.append(col_real)

    if columnas_mencionadas:
        col = columnas_mencionadas[0]
        tabla = (
            df[col]
            .replace("", "Sin dato")
            .value_counts()
            .head(20)
            .reset_index()
        )
        tabla.columns = [col, "total"]
        fig = px.bar(tabla, x=col, y="total", text="total", title=f"Conteo por {col}")
        fig.update_traces(textposition="outside")
        return f"No detecté una pregunta especial, pero sí la columna `{col}`. Generé un conteo.", fig, tabla

    return (
        "No pude identificar la pregunta. Probá escribir algo como: fallecidos por estatus, hipertensión por dictamen, confirmados por entidad, fecha más reciente o diabetes confirmados.",
        None,
        None
    )


# ==========================================================
# CARGA DE ARCHIVO
# ==========================================================

st.sidebar.header("1. Cargar archivo")
archivo = st.sidebar.file_uploader("Subí tu archivo CSV", type=["csv"])

st.sidebar.markdown("---")
st.sidebar.info(
    "Este sistema escanea el CSV y puede responder preguntas creando gráficos automáticos."
)

if archivo is None:
    st.info("Subí un archivo CSV desde el panel izquierdo para comenzar.")
    st.markdown("""
### El sistema incluye:

- Escaneo del CSV: filas, columnas, separador y codificación.
- Perfil de columnas: vacíos, únicos y ejemplos.
- Limpieza de columnas marcadas como **ELIMINAR COLUMNA**.
- Gráficos manuales.
- Dashboard automático para preguntas de salud.
- Módulo de consultas guiadas para preguntas como:
  - ¿Cuántos pacientes han fallecido por cada estatus del caso?
  - ¿Cuántos pacientes con hipertensión hay por cada dictamen?
  - ¿Cuánto es el total de pacientes confirmados por entidad?
  - ¿Cuál es la fecha de actualización más reciente?
  - ¿Cuántos pacientes confirmados padecen diabetes y cuántos no?
""")
    st.stop()

separador = detectar_separador(archivo)
file_bytes = archivo.getvalue()

with st.spinner("Leyendo archivo CSV..."):
    df_original, encoding = leer_csv(file_bytes, separador)

df, columnas_eliminadas, primera_fila_marcador = limpiar_columnas_eliminar(df_original)
numericas, categoricas, fechas = detectar_columnas_por_tipo(df)


tabs = st.tabs([
    "📌 Resumen",
    "🧾 Datos",
    "🔍 Perfil",
    "📊 Dashboard por preguntas",
    "📈 Gráficos manuales",
    "💬 Consultas guiadas",
    "⬇️ Exportar"
])


# ==========================================================
# RESUMEN
# ==========================================================

with tabs[0]:
    st.subheader("Resumen general del archivo")

    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Filas originales", f"{df_original.shape[0]:,}")
    c2.metric("Columnas originales", f"{df_original.shape[1]:,}")
    c3.metric("Filas limpias", f"{df.shape[0]:,}")
    c4.metric("Columnas limpias", f"{df.shape[1]:,}")
    c5.metric("Encoding", encoding)

    st.write(f"**Separador detectado:** `{repr(separador)}`")

    if columnas_eliminadas:
        st.success("Se detectaron y eliminaron columnas marcadas como ELIMINAR COLUMNA.")
        st.write(columnas_eliminadas)
    else:
        st.warning("No se encontraron columnas marcadas como ELIMINAR COLUMNA.")

    if primera_fila_marcador:
        st.info("Se omitió la primera fila porque contenía marcadores de eliminación.")

    st.subheader("Columnas detectadas")
    col_a, col_b, col_c = st.columns(3)
    col_a.write("**Numéricas**")
    col_a.write(numericas if numericas else "No detectadas")
    col_b.write("**Categóricas**")
    col_b.write(categoricas if categoricas else "No detectadas")
    col_c.write("**Fechas**")
    col_c.write(fechas if fechas else "No detectadas")


# ==========================================================
# DATOS
# ==========================================================

with tabs[1]:
    st.subheader("Vista previa de los datos")
    cantidad = st.slider("Cantidad de filas a mostrar", 5, 500, 20)
    st.dataframe(df.head(cantidad), use_container_width=True)

    st.subheader("Buscar texto en el dataset")
    busqueda = st.text_input("Escribí una palabra para buscar en todas las columnas")

    if busqueda:
        mask = df.astype(str).apply(
            lambda col: col.str.contains(busqueda, case=False, na=False)
        ).any(axis=1)
        resultado = df[mask]
        st.write(f"Coincidencias encontradas: **{len(resultado):,}**")
        st.dataframe(resultado.head(200), use_container_width=True)


# ==========================================================
# PERFIL
# ==========================================================

with tabs[2]:
    st.subheader("Perfil de columnas")
    perfil = obtener_perfil_dataframe(df)
    st.dataframe(perfil, use_container_width=True)

    st.subheader("Valores únicos por columna")
    columna_perfil = st.selectbox("Seleccioná una columna", df.columns, key="columna_perfil")
    top_valores = (
        df[columna_perfil]
        .replace("", "Sin dato")
        .value_counts()
        .head(30)
        .reset_index()
    )
    top_valores.columns = [columna_perfil, "total"]
    st.dataframe(top_valores, use_container_width=True)


# ==========================================================
# DASHBOARD POR PREGUNTAS
# ==========================================================

with tabs[3]:
    st.subheader("Dashboard automático basado en preguntas")

    cols, resultados = generar_dashboard_salud(df)

    st.write("**Columnas detectadas para el dashboard:**")
    st.json(cols)

    faltantes = [k for k, v in cols.items() if v is None]
    if faltantes:
        st.warning(f"No se detectaron algunas columnas: {', '.join(faltantes)}. El sistema mostrará solo las preguntas que pueda resolver.")
    else:
        st.success("Se detectaron todas las columnas necesarias para responder las preguntas.")

    top_n_dashboard = st.slider("Top N entidades para el gráfico de confirmados", 5, 40, 15)

    # Pregunta 1
    st.markdown("### 1. ¿Cuántos pacientes han fallecido por cada estatus del caso?")
    if "q1" in resultados:
        q1 = resultados["q1"]
        fig1 = px.bar(
            q1,
            x=cols["estatus"],
            y="total_fallecidos",
            text="total_fallecidos",
            title="Pacientes fallecidos por estatus del caso"
        )
        fig1.update_traces(textposition="outside")
        st.plotly_chart(fig1, use_container_width=True, key='dashboard_q1_fallecidos')
        st.dataframe(q1, use_container_width=True)
    else:
        st.error("No se pudo responder esta pregunta porque faltan columnas.")

    # Pregunta 2
    st.markdown("### 2. ¿Cuántos pacientes con hipertensión hay por cada dictamen?")
    if "q2" in resultados:
        q2 = resultados["q2"]
        fig2 = px.bar(
            q2,
            x="total_pacientes_hipertension",
            y=cols["dictamen"],
            orientation="h",
            text="total_pacientes_hipertension",
            title="Pacientes con hipertensión por dictamen"
        )
        fig2.update_traces(textposition="outside")
        st.plotly_chart(fig2, use_container_width=True, key='dashboard_q2_hipertension')
        st.dataframe(q2, use_container_width=True)
    else:
        st.error("No se pudo responder esta pregunta porque faltan columnas.")

    # Pregunta 3
    st.markdown("### 3. Total de pacientes confirmados por entidad de residencia")
    if "q3" in resultados:
        q3 = resultados["q3"]
        graf = q3.head(top_n_dashboard).sort_values("total_confirmados")
        fig3 = px.bar(
            graf,
            x="total_confirmados",
            y=cols["entidad"],
            orientation="h",
            text="total_confirmados",
            title=f"Top {top_n_dashboard} entidades con más pacientes confirmados"
        )
        fig3.update_traces(textposition="outside")
        st.plotly_chart(fig3, use_container_width=True, key='dashboard_q3_confirmados_entidad')
        st.dataframe(q3, use_container_width=True)
    else:
        st.error("No se pudo responder esta pregunta porque faltan columnas.")

    # Pregunta 4
    st.markdown("### 4. ¿Cuál es la fecha de actualización más reciente?")
    if "q4" in resultados:
        fecha = resultados["q4"]
        texto_fecha = fecha.strftime("%Y-%m-%d") if pd.notna(fecha) else "No disponible"
        st.metric("Fecha más reciente", texto_fecha)
    else:
        st.error("No se pudo responder esta pregunta porque falta la columna de fecha.")

    # Pregunta 5
    st.markdown("### 5. ¿Cuántos pacientes confirmados padecen diabetes y cuántos no?")
    if "q5" in resultados:
        q5 = resultados["q5"]
        fig5 = px.pie(
            q5,
            names=cols["diabetes"],
            values="total_pacientes",
            hole=0.35,
            title="Pacientes confirmados con diabetes y sin diabetes"
        )
        st.plotly_chart(fig5, use_container_width=True, key='dashboard_q5_diabetes')
        st.dataframe(q5, use_container_width=True)
    else:
        st.error("No se pudo responder esta pregunta porque faltan columnas.")


# ==========================================================
# GRÁFICOS MANUALES
# ==========================================================

with tabs[4]:
    st.subheader("Crear visualizaciones manuales")

    tipo_grafico = st.selectbox(
        "Tipo de gráfico",
        [
            "Conteo por categoría",
            "Gráfico circular",
            "Histograma",
            "Barras cruzadas",
            "Línea por fecha",
            "Dispersión"
        ]
    )

    top_n = st.slider("Top N categorías a mostrar", 5, 50, 20, key="top_n_manual")

    x = None
    y = None
    color = None

    if tipo_grafico in ["Conteo por categoría", "Gráfico circular"]:
        x = st.selectbox("Columna categórica", df.columns)

    elif tipo_grafico == "Histograma":
        opciones_num = numericas if numericas else list(df.columns)
        x = st.selectbox("Columna numérica", opciones_num)

    elif tipo_grafico == "Barras cruzadas":
        x = st.selectbox("Primera columna", df.columns)
        y = st.selectbox("Segunda columna", df.columns)

    elif tipo_grafico == "Línea por fecha":
        opciones_fecha = fechas if fechas else list(df.columns)
        x = st.selectbox("Columna fecha", opciones_fecha)

    elif tipo_grafico == "Dispersión":
        opciones_num = numericas if numericas else list(df.columns)
        x = st.selectbox("Columna X numérica", opciones_num)
        y = st.selectbox("Columna Y numérica", opciones_num)
        color = st.selectbox("Color opcional", ["Ninguno"] + list(df.columns))
        if color == "Ninguno":
            color = None

    if st.button("Generar gráfico manual"):
        try:
            fig, tabla = crear_grafico_generico(df, tipo_grafico, x=x, y=y, color=color, top_n=top_n)
            if fig is not None:
                st.plotly_chart(fig, use_container_width=True, key=f'manual_{tipo_grafico}_{x}_{y}_{color}_{top_n}')
                st.subheader("Tabla base del gráfico")
                st.dataframe(tabla, use_container_width=True)
            else:
                st.error("No se pudo generar el gráfico.")
        except Exception as e:
            st.error(f"Error generando gráfico: {e}")


# ==========================================================
# ASISTENTE
# ==========================================================

with tabs[5]:
    st.subheader("Consultas guiadas sobre el CSV")
    st.write("Escribí una pregunta y el sistema intentará detectar columnas, calcular resultados y graficar.")

    ejemplos = [
        "¿Cuántos pacientes han fallecido por cada estatus del caso?",
        "¿Cuántos pacientes con hipertensión hay por cada dictamen?",
        "¿Cuánto es el total de pacientes confirmados por cada entidad de residencia?",
        "¿Cuál es la fecha de actualización más reciente?",
        "¿Cuántos pacientes confirmados padecen diabetes y cuántos no?"
    ]

    ejemplo = st.selectbox("Ejemplos rápidos", [""] + ejemplos)
    pregunta_texto = st.text_input("Pregunta", value=ejemplo)

    if st.button("Analizar pregunta"):
        if pregunta_texto.strip():
            respuesta, fig, tabla = interpretar_pregunta_usuario(pregunta_texto, df)
            st.info(respuesta)

            if fig is not None:
                st.plotly_chart(fig, use_container_width=True, key=f'asistente_{abs(hash(pregunta_texto))}')

            if tabla is not None:
                st.dataframe(tabla, use_container_width=True)
        else:
            st.warning("Escribí una pregunta primero.")


# ==========================================================
# EXPORTAR
# ==========================================================

with tabs[6]:
    st.subheader("Exportar datos limpios")

    csv_limpio = df.to_csv(index=False).encode("utf-8-sig")

    st.download_button(
        label="Descargar CSV limpio",
        data=csv_limpio,
        file_name="dataset_limpio.csv",
        mime="text/csv"
    )

    st.subheader("SQL sugerido para crear tabla en MySQL")
    columnas_sql = ",\n".join([f"`{col}` TEXT NULL" for col in df.columns])
    sql_create = f"""CREATE TABLE dataset_limpio (
    id_etl INT AUTO_INCREMENT PRIMARY KEY,
{columnas_sql}
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"""

    st.code(sql_create, language="sql")
