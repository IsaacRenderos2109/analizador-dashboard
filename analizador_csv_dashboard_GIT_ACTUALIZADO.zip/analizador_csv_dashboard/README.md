# Analizador de CSV y Generador de Dashboards

Sistema web desarrollado en Python con Streamlit para cargar archivos CSV, revisar su estructura, limpiar columnas marcadas para eliminación, explorar datos y generar dashboards con gráficos.

El proyecto está preparado para subirse a GitHub y ejecutarse en otra computadora con instrucciones claras.

---

## Archivos incluidos

```text
analizador_csv_dashboard/
│
├── app.py
├── requirements.txt
├── README.md
├── INSTALACION_USO.md
├── .gitignore
├── instalar_dependencias.bat
└── ejecutar.bat
```

| Archivo | Función |
|---|---|
| `app.py` | Código principal del sistema. |
| `requirements.txt` | Librerías necesarias: Streamlit, Pandas y Plotly. |
| `README.md` | Documentación principal del proyecto. |
| `INSTALACION_USO.md` | Guía rápida de instalación y ejecución. |
| `.gitignore` | Evita subir datasets grandes, entorno virtual y archivos innecesarios. |
| `instalar_dependencias.bat` | Verifica Python, intenta instalarlo si no existe, actualiza pip e instala dependencias. |
| `ejecutar.bat` | Ejecuta el sistema en Windows. |

---

## Funciones principales

- Carga de archivos CSV desde el navegador.
- Detección automática de separador y codificación.
- Resumen del archivo: filas, columnas, encoding y separador.
- Vista previa de registros.
- Perfil de columnas: valores vacíos, valores únicos y ejemplos.
- Limpieza de columnas marcadas como `ELIMINAR COLUMNA`.
- Dashboard automático para preguntas específicas de análisis.
- Gráficos manuales.
- Módulo de consultas guiadas.
- Exportación de CSV limpio.
- SQL sugerido para crear tabla en MySQL.

---

## Instalación recomendada en Windows

### Paso 1: Descargar el proyecto

Desde GitHub:

```powershell
git clone URL_DEL_REPOSITORIO
cd analizador_csv_dashboard
```

O descargar como ZIP desde GitHub, descomprimir y abrir la carpeta.

---

### Paso 2: Instalar dependencias automáticamente

Dar doble clic en:

```text
instalar_dependencias.bat
```

Este archivo hace lo siguiente:

1. Verifica si Python está instalado.
2. Si Python no está instalado, intenta instalarlo con `winget`.
3. Si Python ya está instalado, intenta actualizarlo con `winget` cuando sea posible.
4. Crea un entorno virtual local llamado `.venv`.
5. Actualiza `pip`.
6. Instala las dependencias del archivo `requirements.txt`.

Dependencias:

```text
streamlit
pandas
plotly
```

> Nota: si la computadora no tiene `winget`, se debe instalar Python manualmente desde `https://www.python.org/downloads/` y marcar la opción **Add Python to PATH**.

---

### Paso 3: Ejecutar el sistema

Dar doble clic en:

```text
ejecutar.bat
```

Si todo está correcto, se abrirá el navegador con la aplicación.

Si no se abre automáticamente, entrar a:

```text
http://localhost:8501
```

---

## Instalación manual

Abrir PowerShell dentro de la carpeta del proyecto.

Instalar dependencias:

```powershell
python -m pip install -r requirements.txt
```

Si `python` no funciona:

```powershell
py -m pip install -r requirements.txt
```

Ejecutar el sistema:

```powershell
python -m streamlit run app.py
```

Si `python` no funciona:

```powershell
py -m streamlit run app.py
```

---

## Instalación manual con entorno virtual

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Si PowerShell bloquea la activación:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

Para salir del entorno:

```powershell
deactivate
```

---

## Uso del sistema

1. Ejecutar el programa.
2. Subir un archivo `.csv`.
3. Revisar filas, columnas, separador y codificación.
4. Revisar perfil de columnas.
5. Usar **Dashboard por preguntas** para visualizaciones automáticas.
6. Usar **Gráficos manuales** para visualizaciones personalizadas.
7. Usar **Consultas guiadas** para preguntas sobre el dataset.
8. Exportar el CSV limpio si se necesita.

---

## Preguntas de prueba

```text
¿Cuántos pacientes han fallecido por cada estatus del caso?
```

```text
¿Cuántos pacientes con hipertensión hay por cada dictamen?
```

```text
¿Cuánto es el total de pacientes confirmados por cada entidad de residencia?
```

```text
¿Cuál es la fecha de actualización más reciente?
```

```text
¿Cuántos pacientes confirmados padecen diabetes y cuántos no?
```

---

## Subir a GitHub

```powershell
git init
git add .
git commit -m "Primer commit - analizador CSV dashboard"
git branch -M main
git remote add origin URL_DEL_REPOSITORIO
git push -u origin main
```

---

## Nota sobre datasets

No se recomienda subir archivos CSV grandes o sensibles al repositorio.

El archivo `.gitignore` ignora:

```text
*.csv
*.xlsx
*.xls
```

Cada usuario puede cargar su propio CSV desde la interfaz del sistema.
