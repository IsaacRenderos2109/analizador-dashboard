# Instalación y uso rápido

## Opción recomendada

### 1. Instalar dependencias

Dar doble clic en:

```text
instalar_dependencias.bat
```

Este archivo verifica Python, intenta instalarlo si no existe, crea el entorno virtual `.venv`, actualiza pip e instala las dependencias.

### 2. Ejecutar

Dar doble clic en:

```text
ejecutar.bat
```

Luego abrir:

```text
http://localhost:8501
```

si el navegador no se abre automáticamente.

---

## Instalación manual

```powershell
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Si `python` no funciona:

```powershell
py -m pip install -r requirements.txt
py -m streamlit run app.py
```
